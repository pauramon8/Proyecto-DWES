const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require("swagger-jsdoc");
const bodyParser = require('body-parser');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const config = require("./config/config");
const UserRouter = require('./routes/user.route');
const UrlRouter = require('./routes/url.route');
const ProductRouter = require('./routes/product.route');

// Swagger options
const options = {
  swaggerDefinition: {
    info: {
      title: "User API",
      version: "1.0.0",
      description: "API para administrar usuarios y enlaces recortados",
    },
    host: "api.fmesasc.com",
    basePath: "/v1",
    schemes: ["https"],
  },
  apis: ["./routes/*.js"],
};
const specs = swaggerJsdoc(options);

app.use(bodyParser.json());
app.use(express.static('public'));

app.use('/api/users', UserRouter);
app.use('/api/urls', UrlRouter);
app.use('/api/product', ProductRouter);

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(specs));

wss.on('connection', (ws, req) => {
    ws.on('message', (message) => {
        const parsedMessage = JSON.parse(message);

        if (parsedMessage.type === 'CONNECTION') {
            ws.user = parsedMessage.usuario;
            const usersList = Array.from(wss.clients, (client) => client.user);
            wss.clients.forEach((client) => {
                client.send(JSON.stringify(usersList));
            });
        } else if (parsedMessage.type === 'MESSAGE') {
            const destinationUser = parsedMessage.to;
            console.log(parsedMessage);
            wss.clients.forEach((client) => {
                if (
                    client.readyState === WebSocket.OPEN
                ) {
                    const newmessage = { type: "MESSAGE", mensaje: parsedMessage.mensaje, user: parsedMessage.usuario };
                    console.log(newmessage);
                    if(ws != client) client.send(JSON.stringify(newmessage));
                }
            });
            if (ws.readyState === WebSocket.OPEN) { 
                ws.send(JSON.stringify(parsedMessage));
            }
        }
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
