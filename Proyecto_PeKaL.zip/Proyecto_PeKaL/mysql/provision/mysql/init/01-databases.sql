# create databases
CREATE DATABASE IF NOT EXISTS `ShortenedURLs`;


